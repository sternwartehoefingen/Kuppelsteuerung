#ifndef _Az_Global_H_
#define _Az_Global_H_

#define CCW true
#define CW  false

#define ON true
#define OFF false

#define QUADDIR CW

#endif	// _Az_Global_H_
