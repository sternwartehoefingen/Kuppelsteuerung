#include "./inc/Dome.h"
#include "./inc/AzMounts.h"

int16_t MountPositionOffset = MOUNTOFFSET;
uint8_t MountIdx = 0;
mountPosAttr_t mountPosAttr = POS_none;

mountPosAttr_t CheckMountPosition (int16_t encoderValue)
// return
{
  mountPosAttr_t result = POS_none;
  encoderValue -= MountPositionOffset - MountPosition[0];
  if (encoderValue < MountPosition[0])
    encoderValue += MOUNTPOSMAX;

  /* -----
    Serial.print(" : ");
    Serial.print(MountIdx);
    Serial.print(" ");
    Serial.print(MountPosition[MountIdx]);
    Serial.print("<");
    Serial.print(encoderValue);
    Serial.print("<");
    Serial.print(MountPosition[MountIdx + 1]);
  */

  while (MountPosition[MountIdx] > encoderValue)
    MountIdx--;

  while (MountPosition[MountIdx + 1] <= encoderValue)
    MountIdx++;

  /*
    Serial.print("  v:");
    Serial.print(encoderValue-MountPosition[MountIdx]);
    Serial.print("  v+1:");
    Serial.println(MountPosition[MountIdx+1]-encoderValue);
  */
  bool inVicinity = ((encoderValue - MountPosition[MountIdx]) < MoundHWidth);
  inVicinity = inVicinity || ((MountPosition[MountIdx + 1] - encoderValue) < MoundHWidth);

  if (encoderValue == MountPosition[MountIdx])
    result = POS_center;
  else if (inVicinity)
    result = POS_vicinity;

  else
    result = POS_none;

  return result;
  // POS_none, POS_vicinity, POS_center
}

void Mounts_showState(bool details)
{
  if (details) {
    switch (CheckMountPosition(encoderPos))
    {
      case POS_center  :
        Serial.print("W");
        Serial.print(MountIdx+1);
        break;
      case POS_vicinity  :
        Serial.print("*");
        break;
      default : /* Optional */
        Serial.print(" ");
    }
    Serial.print(" ");
  }
}

